---
id: F-002
title: Open redirect
severity: ""
cvss: ""
author: dora
---

## Description


## Impact


## Steps to Reproduce


## Remediation


## References

